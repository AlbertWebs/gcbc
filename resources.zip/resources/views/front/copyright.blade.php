@extends('front.master-pages')
@section('content')


@endsection